-- phpMyAdmin SQL Dump
-- version 4.3.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 23, 2017 at 09:27 AM
-- Server version: 5.6.24
-- PHP Version: 5.6.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `student`
--

-- --------------------------------------------------------

--
-- Table structure for table `faculty`
--

CREATE TABLE IF NOT EXISTS `faculty` (
  `faculty` varchar(20) NOT NULL,
  `depart` varchar(20) NOT NULL,
  `Projectname` varchar(20) NOT NULL,
  `link` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `faculty`
--

INSERT INTO `faculty` (`faculty`, `depart`, `Projectname`, `link`) VALUES
('nilesh', 'IT', 'Hospital System', 'hospital.php'),
('nilesh', 'IT', 'library System', 'library.php'),
('sushree', 'IT', 'Computer System', 'computer.php'),
('sushree', 'IT', 'Bank System', 'bank.php');

-- --------------------------------------------------------

--
-- Table structure for table `project`
--

CREATE TABLE IF NOT EXISTS `project` (
  `dept` varchar(10) NOT NULL,
  `faculty` varchar(10) NOT NULL,
  `projectname` varchar(20) NOT NULL,
  `assign` date NOT NULL,
  `submission` date NOT NULL,
  `noofstudents` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `project`
--

INSERT INTO `project` (`dept`, `faculty`, `projectname`, `assign`, `submission`, `noofstudents`) VALUES
('it', 'Nilesh', 'toll', '2017-04-02', '2017-04-09', 2);

-- --------------------------------------------------------

--
-- Table structure for table `stud`
--

CREATE TABLE IF NOT EXISTS `stud` (
  `class` varchar(10) NOT NULL,
  `rollno` int(5) NOT NULL,
  `depart` varchar(10) NOT NULL,
  `Projectname` varchar(30) NOT NULL,
  `guide` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stud`
--

INSERT INTO `stud` (`class`, `rollno`, `depart`, `Projectname`, `guide`) VALUES
('fe', 1, 'IT', 'Computer System', 'Sushree maam'),
('fe', 2, 'IT', 'Computer System', 'Sushree maam'),
('fe', 3, 'IT', 'Bank System', 'Sushree maam'),
('fe', 4, 'IT', 'Bank System', 'Sushree maam'),
('se', 1, 'IT', 'Hospital System', 'nilesh'),
('se', 2, 'IT', 'Hospital System', 'nilesh'),
('se', 3, 'IT', 'Library System', 'Nilesh sir'),
('se', 4, 'IT', 'Library System', 'Nilesh sir');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
