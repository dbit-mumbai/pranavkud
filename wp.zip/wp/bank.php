<html>
<head>
</head>
<body>
<center><h1 style="color:red">Bank Management System</h1>
<hr>
<h2 style="color:blue">Abstract</h2>
<p>The Domain “Banking Management System ” keeps the day by day tally record as a complete
banking. It can keep the information of Account type, account opening form, Deposit,
Withdrawal, and Searching the transaction, Transaction report, Individual account
opening form, Group Account. The exciting part of this project is; it displays Transaction
reports, Statistical Summary of Account type and Interest Information.


“Banking  Management System ” keeps the day by day tally record as a complete banking. It can keep the information of Account type, account opening form, Deposit, Withdrawal, and Searching the transaction, Transaction reports, Individual account opening form, Group
Account. The exciting part of this project is; it displays Transaction reports, Statistical
Summary of Account type and Interest Information.</p>
<h2 style="color:blue">Library Management System Project Snapshots</h2>

<table>
<tr><td><img src="ban1.png" width="250" height="250"/></td><td><img src="ban2.png" width="250" height="250"/></td></tr>
<tr><td><img src="ban3.png" width="250" height="250"/></td><td><img src="ban4.png" width="250" height="250"/></td></tr>
</table>
</center>
</body>
</html>