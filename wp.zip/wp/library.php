<html>
<head>
</head>
<body>
<center><h1 style="color:red">Library Management System</h1>
<hr>
<h2 style="color:blue">Abstract</h2>
<p>Manual process of keeping student records, book records, account details, managing employee is very difficult. There are various problems also faced by the student in library such as finding any particular book, information whether book is available or not, for what time this book will be available, searching of books using ISBN number etc. To eliminate this manual system, library management system has been developed. Library Management System will handle all the current issues faced by the students and by its admin personnel.</p>
<p>The current Library Management System does not eliminate the process of searching books within the library campus. Students have to find books manually. They have to wait until they are not provided with their library card and token. For receiving book they have to show their library card and wait in line for their turns. The admin personnel also have to look manually on which day which person will take the charge within library to manage the overall work.</p>
<p>This Library Management System will have login page from where its user can access. This page will provide login for admin, working staff members and the students. Staff members accounts will be manage by the admin. To access the library resources students have to register by using their registration number, email address, phone number, class roll number and password. After successful registration they will be provided the login facility.

Students can search books by using book ISBN number or by author name or by title of book along with author name. After completion of this process students will be provided with book details such as where it is located by using location number and by their row and column number.

If any student has lost their book, then this should be informed to library working staff member where they can made changes to their account and take appropriate actions such as fine.

Admin will able to add staffs, delete staffs, add students, delete students, add books, manage account details, schedule working time table etc.</p>
<p>For receiving book from the Library Management System students have to use their bard code card and provide to the staff members where they will scan their card and add particular book into their account. If any student does not clear their previous dues then it will display a message of defaulter and last date to submit their dues.</p>


<h2 style="color:blue"> Motivation behind this project</h2>
<p><p>To store all the information in the database from where user will place their query and get the results on the basis of their query. Only valid users will be able to access this Library Management System. Through this Library Management System it will be easy to manage accounts and various details of particular student and employees working under library along with the records of book.</p>
<h2 style="color:blue">Library Management System Project Snapshots</h2>

<table>
<tr><td><img src="lib1.jpg" width="250" height="250"/></td><td><img src="lib2.jpg" width="250" height="250"/></td><td><img src="lib3.jpg" width="250" height="250"/></td></tr>
<tr><td><img src="lib4.jpg" width="250" height="250"/></td><td><img src="lib5.jpg" width="250" height="250"/></td><td><img src="lib6.jpg" width="250" height="250"/></td></tr>
</table>
</center>
</body>
</html>