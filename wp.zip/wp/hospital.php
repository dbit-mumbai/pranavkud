<html>
<head>
</head>
<body>
<center><h1 style="color:red">Hospital Management System</h1>
<hr>
<h2 style="color:blue">Abstract</h2>
<p>The Hospital management System is developed to decrease the work that is done manually at Hospital centers. Every single step is done with the help of system, services such as employee registration , editing of different types such as employees , students into database , inquiries as well as complaints of customers. This Hospital management System will help in reducing lots of paper work and file work in these hospitals which will make easy management of hospital. It will also provide all the latest information to the management and hospital administration wherever they ask. Hospital management System also include the pharmacist where anyone can inquire about the drugs availability and the stock to be ordered as well as about its expiry date.</p>
<h2 style="color:blue"> Where the system must be placed?</h2>
<p>There are a lot of benefits to the Health center by placing the system at their registration and at drug store office . At the same time the patients are also benefited using this system. They can get the work done within no time.</p>
<h2 style="color:blue">How to use the system?</h2>
<p>Using the Hospital management System is as simple as using the personal computer. Since end user computing is developing in our country, It is beneficial to both Health center and the patients. Every step is clearly defined and help is provided through out the application to the user.</p>
<h2 style="color:blue"> How is it beneficial to the Health Center?</h2>
<p> The heath center can get much out of the system. The Hospital management System is used to enter the patient details and to enter the details about the health center and the details about the in-patient and out-patient in detail and about the reports of the patients . This system represents the patient by the OP number and this is main criteria how the patient is provided by the free services . The drug information and the specifications is also provided in this Health Center Management System.</p>
<h2 style="color:blue">Hospital management System Snapshots</h2>
<table>
<tr><td><img src="hos1.jpg" width="250" height="250"/></td><td><img src="hos2.jpg" width="250" height="250"/></td><td><img src="hos3.jpg" width="250" height="250"/></td></tr>
<tr><td><img src="hos4.jpg" width="250" height="250"/></td><td><img src="hos5.jpg" width="250" height="250"/></td><td><img src="hos6.jpg" width="250" height="250"/></td></tr>
</table>
</center>
</body>
</html>